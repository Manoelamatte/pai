import styled from "styled-components"

export const ContainerApp = styled.div`
    background-color: #d8d8d8;
    height: 500px;
    padding-top: 5px;
`
export const Paragrafo = styled.p`
    text-align: center;
`

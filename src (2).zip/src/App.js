import {useState} from "react";
import Filho from "./components/Filho/Filho";
import { ContainerApp, Paragrafo } from "./styled";
import { Botao } from "./components/Bisneto/styled";


function App(props) {

  const [TextoInicial, setTextoInicial] = useState("")
 
  return (
    <>
    <ContainerApp>
      <Paragrafo>
        App(Pai)
      </Paragrafo>

{/*      
      <Botao onClick={() => setTextoInicial("Atualizado")}>
      Atualizar
      </Botao> */}

      {TextoInicial}
    <Filho setTextoInicial={setTextoInicial}/>
    </ContainerApp>

    </>
  );
}

export default App;

import Bisneto from "../Bisneto/Bisneto"
import { ContainerNeto, Paragrafo } from "./styled"

function Neto(props){
    return(
        <>
        <ContainerNeto>
           <Paragrafo>
            Neto
           </Paragrafo>
            <Bisneto setTextoInicial={props.setTextoInicial}/>

            

        </ContainerNeto>
        </>

    )

}
export default Neto
import styled from "styled-components"

export const ContainerNeto = styled.div`
    background-color: #f1b7dc;
    height: 250px;
    padding: 15px;
`
export const Paragrafo = styled.p`
    text-align: center;
`

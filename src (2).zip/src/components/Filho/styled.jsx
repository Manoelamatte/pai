import styled from "styled-components"

export const ContainerFilho = styled.div`
    background-color: #00ffea;
    height: 350px;
    padding: 15px;
`

export const Paragrafo = styled.p`
    text-align: center;
`

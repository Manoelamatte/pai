import { ContainerFilho, Paragrafo } from "./styled"
import Neto from "../Neto/Neto"

function Filho(props){

    console.log(props)
    return(
       <>

        <ContainerFilho>
            <Paragrafo>
                Filho
            </Paragrafo>

            
         <Neto setTextoInicial={props.setTextoInicial}/>
        </ContainerFilho>
       </>
    )
}

export default Filho
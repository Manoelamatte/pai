
import { ContainerBisneto, Paragrafo } from "./styled"

function Bisneto(props){

    return(
    <>
    <ContainerBisneto>
        <Paragrafo>
            Bisneto
        </Paragrafo>

       <Paragrafo>
         Botão do componente bisneto 
        </Paragrafo>

        <Paragrafo>
           Clique para atualizar
         </Paragrafo>

        <Paragrafo>
         <button onClick={() => props.setTextoInicial("Atualizado")}>
              Atualizar estado
         </button> 
         </Paragrafo>

     </ContainerBisneto>
    </>
)

}
export default Bisneto 
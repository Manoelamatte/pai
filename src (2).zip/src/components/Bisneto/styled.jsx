import styled from "styled-components"

export const ContainerBisneto = styled.div`
    background-color: orange;
    height: 150px;
    padding-top: 5px;
`
export const Paragrafo = styled.p`
    text-align: center;
`
export const Botao = styled.button`
    align-items: center;
    justify-content: center;
    display: flex;
    
`